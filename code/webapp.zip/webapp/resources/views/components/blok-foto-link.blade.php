<label for="titleImageUrl" class="font-bold">Blok Foto</label>
<p>Geef een url in van een foto die online staat, of upload een foto van je op pc.</p>
<input type="text" name="titleImageUrl" id="titleImageUrl" placeholder="Enter blok foto url"
    class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mb-3" value={{ $url }}>
<input type="file" name="titleImage" id="titleImage" class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mb-3"
    value={{ $url }}>
