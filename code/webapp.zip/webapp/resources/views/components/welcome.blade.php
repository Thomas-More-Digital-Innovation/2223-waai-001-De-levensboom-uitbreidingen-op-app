<div class="flex gap-2 items-end ml-5 mt-5">
    <h1 class="text-2xl">Dashboard</h1>
    <p class="font-[300]">Welcome op het Admin Dashboard</p>
</div>
