
<title>Waaiburg - Vragenlijsten</title>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal94d83615993a70bc08481120b30a1c57325f9275 = $component; } ?>
<?php $component = App\View\Components\ListTitle::resolve(['title' => 'Vragenlijsten','name' => 'questionLists.create'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('list-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ListTitle::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal94d83615993a70bc08481120b30a1c57325f9275)): ?>
<?php $component = $__componentOriginal94d83615993a70bc08481120b30a1c57325f9275; ?>
<?php unset($__componentOriginal94d83615993a70bc08481120b30a1c57325f9275); ?>
<?php endif; ?>
    <table class="border-collapse border border-[#f4f4f4] w-full" aria-describedby="QuestionListCreate">
        <thead>
            <tr>
                <th class="border border-[#f4f4f4] py-2 px-6">Titel</th>
                <th class="border border-[#f4f4f4] py-2 px-6">Gecreerd op</th>
                <th class="border border-[#f4f4f4] py-2 px-6">Laatste gewijzigd op</th>
                <th class="border border-[#f4f4f4] py-2 px-6">Acties</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $questionLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="font-normal">
                    <td class="border border-[#f4f4f4] py-2 px-6 w-1/4"><?php echo e($questionList->title); ?></td>
                    <td class="border border-[#f4f4f4] py-2 px-6 w-1/4"><?php echo e($questionList->created_at); ?></td>
                    <td class="border border-[#f4f4f4] py-2 px-6 w-1/4"><?php echo e($questionList->updated_at); ?></td>
                    <td class="border border-[#f4f4f4] py-2 px-6 w-1/4">
                        <form action="<?php echo e(route('questionLists.destroy', $questionList->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>

                            <a href="<?php echo e(route('questionLists.edit', $questionList->id)); ?>" class="text-wb-blue">Bewerk</a>
                            <span>|</span>

                            <button type="submit" class="text-wb-blue"
                                onclick="return confirm('Ben je zeker dat je deze vragenlijst wilt verwijderen? Alle vragen en antwoorden onder deze vragenlijst zullen ook verwijdert worden');">Verwijder</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('documentation'); ?>
    <?php if (isset($component)) { $__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b = $component; } ?>
<?php $component = App\View\Components\DocumentationLink::resolve(['link' => '/De_Waaiburg_webapp_documentatie.pdf#page=13','text' => 'documentatie over nieuwtjes'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('documentation-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DocumentationLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b)): ?>
<?php $component = $__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b; ?>
<?php unset($__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/questionLists/index.blade.php ENDPATH**/ ?>