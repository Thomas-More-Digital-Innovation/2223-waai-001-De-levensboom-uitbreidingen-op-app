
<title>Waaiburg - Antwoorden</title>
<?php $__env->startSection('content'); ?>

    <style>
        .rotate-transition {
            transform: rotate(180deg);
            transition: transform 0.3s ease;
        }
    </style>

    <h1 class="text-2xl">Antwoorden van <?php echo e($client->firstname); ?> <?php echo e($client->surname); ?></h1>
    <div>
        <?php $__currentLoopData = $tree_parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tree_part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2>
            <button type="button" class="flex items-center justify-between w-full py-5 font-medium text-left text-gray-500 border-b border-gray-200" onclick="toggleTestDiv(<?php echo e($tree_part->id); ?>)">
                <span><?php echo e($tree_part->name); ?></span>
                <svg id="svg-<?php echo e($tree_part->id); ?>" data-accordion-icon class="w-3 h-3 shrink-0" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5 5 1 1 5"/>
                </svg>
            </button>
        </h2>

        <div class="hidden" id="test-<?php echo e($tree_part->id); ?>">
            <table class="border-collapse border border-[#f4f4f4] w-full" aria-describedby="answerList">
                <thead>
                    <tr>
                        <th class="border border-[#f4f4f4] py-2 px-6">Vraag</th>
                        <th class="border border-[#f4f4f4] py-2 px-6">Antwoord</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($question->tree_part_id == $tree_part->id): ?>
                            <tr class="font-normal">
                                <td class="border border-[#f4f4f4] py-2 px-6 w-1/2"><?php echo e($question->content); ?></td>
                                <?php
                                    $answer = $answers->firstWhere('question_id', $question->id);
                                ?>
                                <td class="border border-[#f4f4f4] py-2 px-6 w-1/2">
                                    <?php if($answer): ?>
                                        <?php echo e($answer->answer); ?>

                                    <?php else: ?>
                                        Deze vraag is nog niet ingevuld
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-10">
        <a href="<?php echo e(route('clientLinks.edit', $client->id)); ?>"  class="rounded bg-wb-blue px-5 py-2 text-white font-bold">Vorige pagina</a>
    </div>

    <script>
        function toggleTestDiv(treePartId) {
            const testDiv = document.getElementById(`test-${treePartId}`);
            const svgIcon = document.getElementById(`svg-${treePartId}`);
            
            if (testDiv && svgIcon) {
                testDiv.classList.toggle('hidden');
                svgIcon.classList.toggle('rotate-transition');
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('documentation'); ?>
    <?php if (isset($component)) { $__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b = $component; } ?>
<?php $component = App\View\Components\DocumentationLink::resolve(['link' => '/De_Waaiburg_webapp_documentatie.pdf#page=6','text' => 'documentatie over begeleiders'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('documentation-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DocumentationLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b)): ?>
<?php $component = $__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b; ?>
<?php unset($__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/clientLinks/clientAnswers/index.blade.php ENDPATH**/ ?>