
<title>Waaiburg - Begeleiders</title>
<?php $__env->startSection('content'); ?>
<h1 class="text-2xl">Begeleider wijzigen</h1>
    <form action="<?php echo e(route('mentors.update', $mentor->id)); ?>" method="POST" class="flex flex-col mt-3">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <?php if (isset($component)) { $__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc = $component; } ?>
<?php $component = App\View\Components\Errormessage::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('errormessage'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Errormessage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc)): ?>
<?php $component = $__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc; ?>
<?php unset($__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'firstname','text' => 'Voornaam','value' => $mentor] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'surname','text' => 'Achternaam','value' => $mentor] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'email','text' => 'Email','value' => $mentor] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'type','text' => 'Admin','type' => 'checkbox','required' => 'false','value' => $mentor] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>
        <hr />

        <div id="dropdowns">
            <?php for($i = 0; $i < (count($departmentsList) ? count($departmentsList) : 1); $i++): ?>
                <div id="<?php echo e($i); ?>" class="flex flex-row gap-5">
                    <div>
                        <?php if($i == 0): ?>
                            <div class="flex items-center gap-3 mt-3 mb-3">
                                <label for="role<?php echo e($i); ?>" class="font-bold">Functie</label>
                            </div>
                        <?php endif; ?>
                        <div class="flex items-center">
                            <select name="role<?php echo e($i); ?>" id="role<?php echo e($i); ?>"
                                class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mb-3">
                                <option value="">Kies een Functie</option>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>"
                                        <?php if($role->id == (count($departmentsList) ? $departmentsList[$i]->role_id : 0)): ?> selected <?php endif; ?>>
                                        <?php echo e($role->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div>
                        <?php if($i == 0): ?>
                            <div class="flex items-center gap-3 mt-3 mb-3">
                                <label for="department0" class="font-bold">Afdeling</label>
                                <iconify-icon icon="fa6-solid:plus"
                                    class="text-wb-blue text-xl cursor-pointer"
                                    onclick="addDepartment()" />
                            </div>
                        <?php endif; ?>
                        <div class="flex items-center mb-3">
                            <select name="department<?php echo e($i); ?>"
                                id="department<?php echo e($i); ?>"
                                class="border border-[#d2d6de] px-4 py-2 outline-wb-blue">
                                <option value="">Kies een Afdeling</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->id); ?>"
                                        <?php if($department->id == (count($departmentsList) ? $departmentsList[$i]->department_id : 0)): ?> selected <?php endif; ?>>
                                        <?php echo e($department->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($i != 0): ?>
                                <button onclick="deleteDepartment( '<?php echo e($i); ?>' )"
                                    class="text-wb-blue ml-2">Verwijder</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>
        </div>

        <input name="totalDep" id="totalDep"
            value="<?php echo e(count($departmentsList) ? count($departmentsList) : 1); ?>" class="hidden" />
        <hr />
        <?php if (isset($component)) { $__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d = $component; } ?>
<?php $component = App\View\Components\Contactgegevens::resolve(['contactgegevens' => $mentor] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('contactgegevens'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Contactgegevens::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d)): ?>
<?php $component = $__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d; ?>
<?php unset($__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d); ?>
<?php endif; ?>

        <div class="flex gap-5">
            <?php if (isset($component)) { $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415 = $component; } ?>
<?php $component = App\View\Components\FormButton::resolve(['text' => 'Wijzigen'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415)): ?>
<?php $component = $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415; ?>
<?php unset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415 = $component; } ?>
<?php $component = App\View\Components\FormButton::resolve(['text' => 'Annuleren','link' => 'mentors.index'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415)): ?>
<?php $component = $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415; ?>
<?php unset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415); ?>
<?php endif; ?>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    let nrOfDep = 1;

    function setDepartments(nrOfDepartments) {
        nrOfDep = nrOfDepartments;
    }

    function addDepartment() {
        nrOfDep++;

        let dropdowns = document.getElementById('dropdowns');
        let totalDep = document.getElementById('totalDep');

        let newDropdown = `<div id="${nrOfDep}" class="flex flex-row gap-5">
                          <select name="role${nrOfDep}" id="role${nrOfDep}" class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mb-3">
                            <option value="">Kies een Functie</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
              
                          <div class="flex items-center mb-3">
                            <select name="department${nrOfDep}" id="department${nrOfDep}" class="border border-[#d2d6de] px-4 py-2 outline-wb-blue">
                              <option value="">Kies een Afdeling</option>
                              <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button onclick="deleteDepartment( '${nrOfDep}' )" class="text-wb-blue ml-2">Verwijder</button>
                          </div>
                        </div>`;

        dropdowns.insertAdjacentHTML('beforeend', newDropdown);
        totalDep.value = nrOfDep;
    }

    function deleteDepartment(departmentId) {
        let dropdowns = document.getElementById('dropdowns');
        dropdowns.removeChild(document.getElementById(departmentId));
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/mentors/edit.blade.php ENDPATH**/ ?>