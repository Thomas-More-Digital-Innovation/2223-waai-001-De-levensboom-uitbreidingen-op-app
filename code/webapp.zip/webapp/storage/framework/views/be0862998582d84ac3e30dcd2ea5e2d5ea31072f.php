<label for="titleImageUrl" class="font-bold">Blok Foto</label>
<p>Geef een url in van een foto die online staat, of upload een foto van je op pc.</p>
<input type="text" name="titleImageUrl" id="titleImageUrl" placeholder="Enter blok foto url"
    class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mb-3" value=<?php echo e($url); ?>>
<input type="file" name="titleImage" id="titleImage" class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mb-3"
    value=<?php echo e($url); ?>>
<?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/components/blok-foto-link.blade.php ENDPATH**/ ?>