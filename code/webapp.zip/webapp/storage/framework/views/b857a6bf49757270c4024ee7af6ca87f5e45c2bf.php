<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
<script src="https://code.iconify.design/iconify-icon/1.0.2/iconify-icon.min.js"
    integrity="sha384-Wg6YZl1ug3L+m2P1dI9UyM3bbDxm861GXqDX7y1TetknKz8/0AoMTJT0Ktlm2Tgi" crossorigin="anonymous">
</script>
<script src="https://cdn.ckeditor.com/4.20.2/full/ckeditor.js"
    integrity="sha384-YfSzYL1sDylXi5TVFdhLEG6HcUdHjsjPeJ+6yUTybeVgczFkdEDx71I0UsKfDsRa" crossorigin="anonymous">
</script>

<?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/head.blade.php ENDPATH**/ ?>