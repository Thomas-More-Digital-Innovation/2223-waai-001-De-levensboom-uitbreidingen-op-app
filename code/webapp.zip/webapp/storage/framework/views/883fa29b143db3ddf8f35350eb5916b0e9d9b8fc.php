<!doctype html>
<html lang="nl">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="https://code.iconify.design/iconify-icon/1.0.2/iconify-icon.min.js"
        integrity="sha384-Wg6YZl1ug3L+m2P1dI9UyM3bbDxm861GXqDX7y1TetknKz8/0AoMTJT0Ktlm2Tgi" crossorigin="anonymous">
    </script>
    <title>Waaiburg - Dashboard</title>
</head>

<body class="flex">
    <?php if(Hash::check('veranderMij', $currentUser->password)): ?>
        <div id="defaultModal" tabindex="-1" aria-hidden="true"
            class="fixed top-0 left-0 h-full w-full right-0 overflow-x-hidden overflow-y-auto flex items-center justify-center">
            <div class="h-full w-full bg-black absolute opacity-60"></div>
            <div class="relative w-full h-full max-w-2xl md:h-auto">
                <!-- Modal content -->
                <div class="relative bg-white rounded-lg shadow">
                    <!-- Modal header -->
                    <div class="flex items-start justify-between p-4 border-b rounded-t ">
                        <h3 class="text-xl font-semibold text-gray-900">
                            Verander je wachtwoord!
                        </h3>
                    </div>
                    <!-- Modal body -->
                    <div class="p-6 space-y-6">
                        <p class="text-base leading-relaxed text-gray-500">
                            Je wachtwoord is onveilig!
                        </p>
                        <p class="text-base leading-relaxed text-gray-500">
                            Je kan het veranderen in <a href="/user#Pass"
                                class="text-blue-500 underline hover:text-blue-900">Beheer account</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
    <main class="w-full bg-white">
        <?php if (isset($component)) { $__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6 = $component; } ?>
<?php $component = App\View\Components\Topbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6)): ?>
<?php $component = $__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6; ?>
<?php unset($__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67 = $component; } ?>
<?php $component = App\View\Components\Welcome::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('welcome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Welcome::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67)): ?>
<?php $component = $__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67; ?>
<?php unset($__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67); ?>
<?php endif; ?>

        <div class="grid grid-cols-3 gap-5 m-5">
            <a href="/clients" class="flex rounded-sm border shadow-md bg-white">
                <iconify-icon icon="fa6-solid:users" class="bg-wb-cyan self-center p-6 text-5xl text-white">
                </iconify-icon>
                <div class=" px-3 py-2 text-wb-blue font-medium">
                    <p>CLIENTEN</p>
                    <p class="font-bold text-wb-blue"><?php echo e($clientcount); ?></p>
                </div>
            </a>

            <a href="/mentors" class="flex rounded-sm border shadow-md bg-white">
                <iconify-icon icon="fa6-solid:address-card"
                    class="bg-wb-yellow self-center px-7 py-6 text-5xl text-white"></iconify-icon>
                <div class="px-3 py-2 text-wb-blue font-medium">
                    <p>BEGELEIDERS</p>
                    <p class="font-bold text-wb-blue"><?php echo e($mentorcount); ?></p>
                </div>
            </a>

            <a href="/departments" class="flex rounded-sm border shadow-md bg-white">
                <iconify-icon icon="fa6-solid:building" class="bg-wb-blue self-center px-9 py-6 text-5xl text-white">
                </iconify-icon>
                <div class="px-3 py-2 text-wb-blue font-medium">
                    <p>AFDELINGEN</p>
                    <p class="font-bold text-wb-blue"><?php echo e($departmentcount); ?></p>
                </div>
            </a>

            <a href="/news" class="flex rounded-sm border shadow-md bg-white">
                <iconify-icon icon="fa6-solid:info" class="bg-wb-lightblue self-center px-11 py-6 text-5xl text-white">
                </iconify-icon>
                <div class="px-3 py-2 text-wb-blue font-medium">
                    <p>NIEUWTJES</p>
                    <p class="font-bold text-wb-blue"><?php echo e($newscount); ?></p>
                </div>
            </a>
        </div>
        <?php if (isset($component)) { $__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b = $component; } ?>
<?php $component = App\View\Components\DocumentationLink::resolve(['link' => '/De_Waaiburg_webapp_documentatie.pdf'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('documentation-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DocumentationLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b)): ?>
<?php $component = $__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b; ?>
<?php unset($__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b); ?>
<?php endif; ?>
    </main>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/index.blade.php ENDPATH**/ ?>