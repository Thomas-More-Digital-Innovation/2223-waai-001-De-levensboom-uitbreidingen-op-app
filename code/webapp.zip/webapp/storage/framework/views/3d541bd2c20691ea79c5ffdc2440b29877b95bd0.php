<!doctype html>
<html lang="nl">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="https://code.iconify.design/iconify-icon/1.0.2/iconify-icon.min.js"
        integrity="sha384-Wg6YZl1ug3L+m2P1dI9UyM3bbDxm861GXqDX7y1TetknKz8/0AoMTJT0Ktlm2Tgi" crossorigin="anonymous">
    </script>
    <title>Waaiburg - Clienten</title>
</head>

<body class="flex relative" onload="setDepartments('<?php echo e(count($departmentsList) ? count($departmentsList) : 1); ?>')">
    <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
    <main class="w-full bg-white">
        <?php if (isset($component)) { $__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6 = $component; } ?>
<?php $component = App\View\Components\Topbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6)): ?>
<?php $component = $__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6; ?>
<?php unset($__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67 = $component; } ?>
<?php $component = App\View\Components\Welcome::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('welcome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Welcome::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67)): ?>
<?php $component = $__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67; ?>
<?php unset($__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67); ?>
<?php endif; ?>

        <div class="m-5 bg-white rounded border">
            <div class="border-t-4 rounded border-wb-blue">
                <div class="m-3">
                    <h1 class="text-2xl">Client wijzigen</h1>
                    <form action="<?php echo e(route('clients.update', $client->id)); ?>" method="POST" class="flex flex-col mt-3">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <?php if (isset($component)) { $__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc = $component; } ?>
<?php $component = App\View\Components\Errormessage::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('errormessage'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Errormessage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc)): ?>
<?php $component = $__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc; ?>
<?php unset($__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'firstname','text' => 'Voornaam','value' => $client] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'surname','text' => 'Achternaam','value' => $client] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'email','text' => 'Email','type' => 'email','value' => $client] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'birthdate','text' => 'Geboortedatum','type' => 'date','value' => $client,'required' => 'false'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>

                        <label for="gender" class="font-bold">Geslacht</label>
                        <select name="gender" id="gender"
                            class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mb-5">
                            <option value="man">Man</option>
                            <option value="woman">Vrouw</option>
                        </select>
                        <hr>

                        <div id='dropdowns'>
                            <?php for($i = 0; $i < (count($userDepartments) ? count($userDepartments) : 1); $i++): ?>
                                <div id='<?php echo e($i); ?>'>
                                    <div class="flex flex-row gap-5">
                                        <div>
                                            <?php if($i == 0): ?>
                                                <div class="flex items-center gap-3 mt-3 mb-3">
                                                    <label for="department<?php echo e($i); ?>"
                                                        class="font-bold">Afdeling</label>
                                                </div>
                                            <?php endif; ?>
                                            <select
                                                onchange="getDepartments(<?php echo e($departmentsList); ?>, <?php echo e($mentors); ?>, 'department<?php echo e($i); ?>', 'mentor<?php echo e($i); ?>')"
                                                name="department<?php echo e($i); ?>" id="department<?php echo e($i); ?>"
                                                class="border border-[#d2d6de] px-4 py-2 outline-wb-blue">
                                                <option value="">Kies een Afdeling</option>
                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($department->id); ?>"
                                                        <?php if($department->id == (count($userDepartments) ? $userDepartments[$i]->department_id : 0)): ?> selected <?php endif; ?>>
                                                        <?php echo e($department->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <?php if($i == 0): ?>
                                                <div class="flex items-center gap-3 mt-3 mb-3">
                                                    <label for="mentor<?php echo e($i); ?>"
                                                        class="font-bold">Begeleiders</label>
                                                    <iconify-icon icon="fa6-solid:plus"
                                                        class="text-wb-blue text-xl cursor-pointer"
                                                        onclick="addDepartment()" />
                                                </div>
                                            <?php endif; ?>
                                            <div class="flex items-center mb-3">
                                                <select name="mentor<?php echo e($i); ?>"
                                                    id="mentor<?php echo e($i); ?>"
                                                    class="border border-[#d2d6de] px-4 py-2 outline-wb-blue">
                                                    <option value="">Kies een Begeleider</option>
                                                    <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $departmentsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(
                                                                $department->department_id == (count($userDepartments) ? $userDepartments[$i]->department_id : 0) &&
                                                                    $department->user_id == $mentor->id): ?>
                                                                <option value="<?php echo e($mentor->id); ?>"
                                                                    <?php if(count($usersList)): ?> <?php if($usersList[$i]->mentor_id == $mentor->id): ?>
                                      selected <?php endif; ?>
                                                                    <?php endif; ?>
                                                                    >
                                                                    <?php echo e($mentor->firstname); ?> <?php echo e($mentor->surname); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($i != 0): ?>
                                                    <button onclick="deleteDepartment( '<?php echo e($i); ?>' )"
                                                        class="text-wb-blue ml-2">Verwijder</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endfor; ?>
                        </div>

                        <input name="totalDep" id="totalDep"
                            value="<?php echo e(count($userDepartments) ? count($userDepartments) : 1); ?>" class="hidden" />
                        <hr>
                        <?php if (isset($component)) { $__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d = $component; } ?>
<?php $component = App\View\Components\Contactgegevens::resolve(['contactgegevens' => $client] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('contactgegevens'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Contactgegevens::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d)): ?>
<?php $component = $__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d; ?>
<?php unset($__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d); ?>
<?php endif; ?>

                        <div class="flex gap-5">
                            <?php if (isset($component)) { $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415 = $component; } ?>
<?php $component = App\View\Components\FormButton::resolve(['text' => 'Wijzigen'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415)): ?>
<?php $component = $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415; ?>
<?php unset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415 = $component; } ?>
<?php $component = App\View\Components\FormButton::resolve(['text' => 'Annuleren','link' => 'clients.index'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415)): ?>
<?php $component = $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415; ?>
<?php unset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="m-5 bg-white rounded border">
            <div class="border-t-4 rounded border-[#f39c12]">
                <div class="m-3">
                    <h1 class="text-2xl">Tevredenheids meting</h1>
                    <form action="<?php echo e(route('clients.sendSurvey', ['id' => $client->id])); ?>?survey_id=">
                        <?php echo csrf_field(); ?>
                        <select name="survey_id" id="surveySelect"
                            class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mt-5">
                            <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($survey->id); ?>"><?php echo e($survey->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($client->survey == null): ?>
                            <p class="mt-5 mb-7">Er is nog geen tevredenheids meting verstuurd naar deze client</p>
                            <button type="submit" class="bg-[#f39c12] rounded px-4 py-2 mt-5 text-white"
                                onclick="return confirm('Ben je zeker dat je deze tevredenheidsmeting wilt sturen?);">Tevredenheids
                                meting versturen</button>
                        <?php else: ?>
                            <p class="mt-5 mb-7">Een tevredenheids meting is reeds verstuurd naar deze client, laatst
                                verstuurd op <?php echo e($client->survey); ?></p>
                            <button type="submit" class="bg-[#f39c12] rounded px-4 py-2 mt-5 text-white"
                                onclick="return confirm('Ben je zeker dat je deze tevredenheidsmeting wilt sturen?);">Tevredenheids
                                meting opnieuw versturen</button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

    </main>
</body>

<script>
    let nrOfDep = 1;

    function setDepartments(nrOfDepartments) {
        nrOfDep = nrOfDepartments;
    }

    function getDepartments(departmentsList, allMentors, departmentId, mentorId) {
        selectedDepartments = document.getElementById(departmentId).value;
        let mentorDropdown = document.getElementById(mentorId);
        let departments = []
        let mentors = []

        // Loop through the departmentsList array
        for (let i = 0; i < departmentsList.length; i++) {
            // search for the selected departmentsList with only Mentors and Department Heads
            if (departmentsList[i].department_id == selectedDepartments && departmentsList[i].role_id != 2) {
                // Push the user_id to the mentors array
                mentors.push(departmentsList[i].user_id)
            }
        }

        //Delete all options in the mentorDropdown
        while (mentorDropdown.firstChild) {
            mentorDropdown.removeChild(mentorDropdown.firstChild);
        }
        // Make new standard option
        let option = document.createElement('option');
        option.value = '';
        option.text = 'Kies een Begeleider';
        mentorDropdown.appendChild(option)

        // Loop through the allMentors array
        for (let i = 0; i < allMentors.length; i++) {
            if (mentors.includes(allMentors[i].id)) {
                // make new option
                let option = document.createElement('option');
                option.value = allMentors[i].id;
                option.text = allMentors[i].firstname + ' ' + allMentors[i].surname;
                mentorDropdown.appendChild(option);
            }
        }
    }

    function addDepartment() {
        nrOfDep++;

        let dropdowns = document.getElementById('dropdowns');
        let totalDep = document.getElementById('totalDep');

        let newDropdown = `<div id='${nrOfDep}' class="flex flex-row gap-5">
                          <div class="flex items-center mb-5">
                            <select
                              onchange="getDepartments(<?php echo e($departmentsList); ?>, <?php echo e($mentors); ?>, 'department${nrOfDep}', 'mentor${nrOfDep}')" name="department${nrOfDep}" id="department${nrOfDep}"
                              class="border border-[#d2d6de] px-4 py-2 outline-wb-blue">
                              <option value="">Kies een Afdeling</option>
                              <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>

                          <div class="flex items-center mb-5">
                            <select
                              name="mentor${nrOfDep}"
                              id="mentor${nrOfDep}"
                              class="border border-[#d2d6de] px-4 py-2 outline-wb-blue">
                              <option value="">Kies een Begeleider</option>
                            </select>
                            <button onclick="deleteDepartment( '${nrOfDep}' )" class="text-wb-blue ml-2">Verwijder</button>
                          </div>
                        </div>`;

        dropdowns.insertAdjacentHTML('beforeend', newDropdown);
        totalDep.value = nrOfDep;
    }

    function deleteDepartment(departmentId) {
        let dropdowns = document.getElementById('dropdowns');
        dropdowns.removeChild(document.getElementById(departmentId));
    }
</script>

</html>
<?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/clients/edit.blade.php ENDPATH**/ ?>