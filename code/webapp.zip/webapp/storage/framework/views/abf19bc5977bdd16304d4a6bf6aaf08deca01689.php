<?php if($type == 'checkbox'): ?>
    <div class="flex gap-5 items-center mb-3">
        <label for="<?php echo e($name); ?>"
            class="font-bold"><?php echo e($text); ?><?php echo e($required === 'true' ? '*' : ''); ?></label>
        <?php if($value != null): ?>
            <input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>"
                <?php echo e($required === 'true' ? 'required' : null); ?> <?php echo e($disabled); ?>

                placeholder="Enter <?php echo e(strtolower($text)); ?>"
                class="border border-[#d2d6de] px-4 py-2 outline-wb-blue <?php $__errorArgs = ["<?php echo e($name); ?>"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                <?php echo e($value->user_type_id==1 ? 'checked': ''); ?>>
        <?php else: ?>
            <input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>"
                <?php echo e($required === 'true' ? 'required' : null); ?> <?php echo e($disabled); ?>

                placeholder="Enter <?php echo e(strtolower($text)); ?>"
                class="border border-[#d2d6de] px-4 py-2 outline-wb-blue <?php $__errorArgs = ["<?php echo e($name); ?>"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php if(old($name)): echo 'checked'; endif; ?> value=>
        <?php endif; ?>
    </div>
<?php else: ?>
    <label for="<?php echo e($name); ?>"
        class="font-bold"><?php echo e($text); ?><?php echo e($required === 'true' ? '*' : ''); ?></label>
    <?php if($value != null): ?>
        <input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>"
            <?php echo e($required === 'true' ? 'required' : null); ?> <?php echo e($disabled); ?>

            placeholder="Enter <?php echo e(strtolower($text)); ?>"
            class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mb-3 <?php $__errorArgs = ["<?php echo e($name); ?>"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e($value->$name); ?>">
    <?php else: ?>
        <input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>"
            <?php echo e($required === 'true' ? 'required' : null); ?> <?php echo e($disabled); ?>

            placeholder="Enter <?php echo e(strtolower($text)); ?>"
            class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mb-3 <?php $__errorArgs = ["<?php echo e($name); ?>"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(old($name)); ?>">
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/components/form-input.blade.php ENDPATH**/ ?>