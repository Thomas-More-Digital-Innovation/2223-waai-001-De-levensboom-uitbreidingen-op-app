<!doctype html>
<html lang="nl">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Waaiburg - Jongeren</title>
    <script src="https://cdn.ckeditor.com/4.20.2/full/ckeditor.js"
        integrity="sha384-YfSzYL1sDylXi5TVFdhLEG6HcUdHjsjPeJ+6yUTybeVgczFkdEDx71I0UsKfDsRa" crossorigin="anonymous">
    </script>
</head>

<body class="flex">
    <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
    <main class="w-full bg-white">
        <?php if (isset($component)) { $__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6 = $component; } ?>
<?php $component = App\View\Components\Topbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6)): ?>
<?php $component = $__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6; ?>
<?php unset($__componentOriginala1d1286e4cf0959506a555d2d7a5615acaf3f6a6); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67 = $component; } ?>
<?php $component = App\View\Components\Welcome::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('welcome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Welcome::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67)): ?>
<?php $component = $__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67; ?>
<?php unset($__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67); ?>
<?php endif; ?>

        <div class="flex flex-row">
            <div class="m-5 bg-white rounded border flex w-full flex-col h-full">
                <div class="border-t-4 rounded border-wb-blue">
                    <div class="m-3">
                        <h1 class="text-2xl">Info blok toevoegen</h1>
                        <form action="<?php echo e(route('teenInfoContents.store', ['info_id' => $info_id])); ?>" method="POST"
                            class="flex flex-col mt-3">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>

                            <?php if (isset($component)) { $__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc = $component; } ?>
<?php $component = App\View\Components\Errormessage::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('errormessage'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Errormessage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc)): ?>
<?php $component = $__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc; ?>
<?php unset($__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'title','text' => 'Titel'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.blok-foto-link','data' => ['url' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('blok-foto-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'url','text' => 'Meer info link','required' => 'false'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>

                            <label for="text" class="font-bold">Inhoud</label>
                            <textarea class="ckeditor form-control" name="content"></textarea>

                            <div class="flex gap-5">
                                <?php if (isset($component)) { $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415 = $component; } ?>
<?php $component = App\View\Components\FormButton::resolve(['text' => 'Aanmaken'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415)): ?>
<?php $component = $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415; ?>
<?php unset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415 = $component; } ?>
<?php $component = App\View\Components\FormButton::resolve(['text' => 'Annuleren','link' => 'teens.index'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415)): ?>
<?php $component = $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415; ?>
<?php unset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415); ?>
<?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/teens/infoContents/create.blade.php ENDPATH**/ ?>