
<title>Waaiburg - Clienten</title>
<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl">Client toevoegen</h1>
    <form action="<?php echo e(route('clients.store')); ?>" method="POST" class="flex flex-col mt-3">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>

        <?php if (isset($component)) { $__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc = $component; } ?>
<?php $component = App\View\Components\Errormessage::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('errormessage'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Errormessage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc)): ?>
<?php $component = $__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc; ?>
<?php unset($__componentOriginal0de6263cd3e34739b4c691c3c95d158e68bf89cc); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'firstname','text' => 'Voornaam'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'surname','text' => 'Achternaam'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'email','text' => 'Email','type' => 'email'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2 = $component; } ?>
<?php $component = App\View\Components\FormInput::resolve(['name' => 'birthdate','text' => 'Geboortedatum','type' => 'date','required' => 'false'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2)): ?>
<?php $component = $__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2; ?>
<?php unset($__componentOriginal52d3950588707db14f7ba1be26bca751b90c06a2); ?>
<?php endif; ?>


        <label for="gender" class="font-bold">Geslacht</label>
        <select name="gender" id="gender" class="border border-[#d2d6de] px-4 py-2 outline-wb-blue mb-5">
            <option value="man">Man</option>
            <option value="woman">Vrouw</option>
        </select>
        <hr>

        <div id='dropdowns'>
            <div id='0'>
                <div class="flex flex-row gap-5">
                    <div>
                        <div class="flex items-center gap-3 mt-3 mb-3">
                            <label for="department0" class="font-bold">Afdeling</label>
                        </div>
                        <select name="department0" id="department0"
                            onchange="getDepartments(<?php echo e($departmentLists); ?>, <?php echo e($mentors); ?>, 'department0', 'mentor0')"
                            class="border border-[#d2d6de] px-4 py-2 outline-wb-blue">
                            <option value="">Kies een Afdeling</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <div class="flex items-center gap-3 mt-3 mb-3">
                            <label for="mentor0" class="font-bold">Begeleiders</label>
                            <iconify-icon icon="fa6-solid:plus" class="text-wb-blue text-xl cursor-pointer"
                                onclick="addDepartment()" />
                        </div>
                        <div class="flex items-center mb-3">
                            <select name="mentor0" id="mentor0" class="border border-[#d2d6de] px-4 py-2 outline-wb-blue">
                                <option value="">Kies een Begeleider</option>
                                <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mentor->id); ?>"><?php echo e($mentor->firstname); ?>

                                        <?php echo e($mentor->surname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <input name="totalDep" id="totalDep" value="1" class="hidden" />
        <hr>
        <?php if (isset($component)) { $__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d = $component; } ?>
<?php $component = App\View\Components\Contactgegevens::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('contactgegevens'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Contactgegevens::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d)): ?>
<?php $component = $__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d; ?>
<?php unset($__componentOriginal87bbed21c44ce83c6f78c60f404d82125f10cd2d); ?>
<?php endif; ?>
        <div class="flex gap-5">
            <?php if (isset($component)) { $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415 = $component; } ?>
<?php $component = App\View\Components\FormButton::resolve(['text' => 'Aanmaken'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415)): ?>
<?php $component = $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415; ?>
<?php unset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415 = $component; } ?>
<?php $component = App\View\Components\FormButton::resolve(['text' => 'Annuleren','link' => 'clients.index'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FormButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415)): ?>
<?php $component = $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415; ?>
<?php unset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415); ?>
<?php endif; ?>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        let nrOfDep = 1;

        function getDepartments(departmentLists, allMentors, departmentId, mentorId) {
            selectedDepartments = document.getElementById(departmentId).value;
            let mentorDropdown = document.getElementById(mentorId);
            let departments = []
            let mentors = []

            // Loop through the departmentLists array
            for (let i = 0; i < departmentLists.length; i++) {
                // search for the selected departmentLists with only Mentors and Department Heads
                if (departmentLists[i].department_id == selectedDepartments && departmentLists[i].role_id != 2) {
                    // Push the user_id to the mentors array
                    mentors.push(departmentLists[i].user_id)
                }
            }

            //Delete all options in the mentorDropdown
            while (mentorDropdown.firstChild) {
                mentorDropdown.removeChild(mentorDropdown.firstChild);
            }
            // Make new standard option
            let option = document.createElement('option');
            option.value = '';
            option.text = 'Kies een Begeleider';
            mentorDropdown.appendChild(option)

            // Loop through the allMentors array
            for (let i = 0; i < allMentors.length; i++) {
                if (mentors.includes(allMentors[i].id)) {
                    // make new option
                    let option = document.createElement('option');
                    option.value = allMentors[i].id;
                    option.text = allMentors[i].firstname + ' ' + allMentors[i].surname;
                    mentorDropdown.appendChild(option);
                }
            }
        }

        function addDepartment() {
            nrOfDep++;

            let dropdowns = document.getElementById('dropdowns');
            let totalDep = document.getElementById('totalDep');

            let newDropdown = `<div id='${nrOfDep}' class="flex flex-row gap-5">
                        <div class="flex items-center mb-5">
                          <select onchange="getDepartments(<?php echo e($departmentLists); ?>, <?php echo e($mentors); ?>, 'department${nrOfDep}', 'mentor${nrOfDep}')" name="department${nrOfDep}" id="department${nrOfDep}" class="border border-[#d2d6de] px-4 py-2 outline-wb-blue">
                            <option value="">Kies een Afdeling</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                        <div class="flex items-center mb-5">
                          <select name="mentor${nrOfDep}" id="mentor${nrOfDep}" class="border border-[#d2d6de] px-4 py-2 outline-wb-blue">
                            <option value="">Kies een Begeleider</option>
                          </select>
                          <button onclick="deleteDepartment( '${nrOfDep}' )" class="text-wb-blue ml-2">Verwijder</button>
                        </div>
                      </div>`;

            dropdowns.insertAdjacentHTML('beforeend', newDropdown);
            totalDep.value = nrOfDep;
        }

        function deleteDepartment(departmentId) {
            let dropdowns = document.getElementById('dropdowns');
            dropdowns.removeChild(document.getElementById(departmentId));
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/clients/create.blade.php ENDPATH**/ ?>