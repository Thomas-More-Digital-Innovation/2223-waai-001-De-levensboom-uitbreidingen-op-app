<table class="subcopy" width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td>
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
<?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/vendor/mail/html/subcopy.blade.php ENDPATH**/ ?>