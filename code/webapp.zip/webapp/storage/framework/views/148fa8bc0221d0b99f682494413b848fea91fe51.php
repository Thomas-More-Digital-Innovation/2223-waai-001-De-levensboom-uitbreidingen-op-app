
<title>Waaiburg - Clienten</title>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal94d83615993a70bc08481120b30a1c57325f9275 = $component; } ?>
<?php $component = App\View\Components\ListTitle::resolve(['title' => 'Clienten lijst','name' => 'clients.create'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('list-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ListTitle::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal94d83615993a70bc08481120b30a1c57325f9275)): ?>
<?php $component = $__componentOriginal94d83615993a70bc08481120b30a1c57325f9275; ?>
<?php unset($__componentOriginal94d83615993a70bc08481120b30a1c57325f9275); ?>
<?php endif; ?>
    <table class="border-collapse border border-[#f4f4f4] w-full" aria-describedby="clientCreate">
        <thead>
            <tr>
                <th class="border border-[#f4f4f4] py-2 px-6">Voornaam</th>
                <th class="border border-[#f4f4f4] py-2 px-6">Achternaam</th>
                <th class="border border-[#f4f4f4] py-2 px-6">Afdeling&lpar;en&rpar;</th>
                <th class="border border-[#f4f4f4] py-2 px-6">Begeleider&lpar;s&rpar;</th>
                <th class="border border-[#f4f4f4] py-2 px-6">Geboortedatum</th>
                <th class="border border-[#f4f4f4] py-2 px-6">Contactgegevens</th>
                <th class="border border-[#f4f4f4] py-2 px-">Acties</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="font-normal">
                    <td class="border border-[#f4f4f4] py-2 px-6"><?php echo e($client->firstname); ?></td>
                    <td class="border border-[#f4f4f4] py-2 px-6"><?php echo e($client->surname); ?></td>
                    <td class="border border-[#f4f4f4] py-2 px-6 align-text-top text-left">
                        <?php $__currentLoopData = $departmentLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departmentList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($departmentList->where('user_id', $client->id)->doesntExist()): ?>
                                <p>Geen afdeling</p>
                            <?php break; ?>
                        <?php endif; ?>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($departmentList->department_id == $department->id && $departmentList->user_id == $client->id): ?>
                                <p><?php echo e($department->name); ?></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td class="border border-[#f4f4f4] py-2 px-6">
                    <?php $__currentLoopData = $userLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($userList->where('client_id', $client->id)->doesntExist()): ?>
                            <p>Geen begeleider</p>
                        <?php break; ?>
                    <?php endif; ?>
                    <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($userList->mentor_id == $mentor->id && $userList->client_id == $client->id): ?>
                            <p>-<?php echo e($mentor->firstname . ' ' . $mentor->surname); ?></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td class="border border-[#f4f4f4] py-2 px-6"><?php echo e($client->birthdate); ?></td>
            <td class="border border-[#f4f4f4] py-2 px-6">
                <?php echo e($client->street . ' ' . $client->houseNumber); ?> <br>
                <?php echo e($client->city . ' ' . $client->zipcode); ?> <br> <?php echo e($client->phoneNumber); ?>

                <br> <?php echo e($client->email); ?>

            </td>
            <td class="border border-[#f4f4f4] py-2 px-6">
                <form action="<?php echo e(route('clients.destroy', $client->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>

                    <a href="<?php echo e(route('clients.edit', $client->id)); ?>" class="text-wb-blue">Bewerk</a>
                    <span>|</span>

                    <button type="submit" class="text-wb-blue"
                        onclick="return confirm('Ben je zeker dat je deze client wilt verwijderen?');">Verwijder</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('documentation'); ?>
<?php if (isset($component)) { $__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b = $component; } ?>
<?php $component = App\View\Components\DocumentationLink::resolve(['link' => '/De_Waaiburg_webapp_documentatie.pdf#page=3','text' => 'documentatie over clienten'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('documentation-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DocumentationLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b)): ?>
<?php $component = $__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b; ?>
<?php unset($__componentOriginalc6db121c1ca0463a435b9150d9260628faac053b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/clients/index.blade.php ENDPATH**/ ?>