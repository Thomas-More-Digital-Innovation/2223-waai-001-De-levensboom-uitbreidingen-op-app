<?php if($link == true): ?>
    <a href="<?php echo e(route($link)); ?>" class="bg-gray-500 rounded px-4 py-1 mt-5 text-white"><?php echo e($text); ?></a>
<?php else: ?>
    <button type="submit" class="bg-wb-blue rounded px-4 py-1 mt-5 text-white"><?php echo e($text); ?></button>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\2223-waai-001-waaiburg-web-app\code\webapp\resources\views/components/form-button.blade.php ENDPATH**/ ?>